//
//  QuizQuestions.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 14.07.2024.
//

import Foundation

struct QuizQuestion: Identifiable, Equatable, Hashable {
    var id: String
    var category: String
    var question: String

    static func ==(lhs: QuizQuestion, rhs: QuizQuestion) -> Bool {
        return lhs.id == rhs.id &&
               lhs.category == rhs.category &&
               lhs.question == rhs.question
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(category)
        hasher.combine(question)
    }
}
