//
//  Challenge.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 26.07.2024.
//

import SwiftData
import Foundation

@Model
class Challenge: Identifiable {
    var id: String = ""
    var healthCategory: String = "" // hipo - hiper - sanatos
    var activityCategory: String = "" // text - imagini - pasi
    var stringContent: String = ""
    var minImageCount: Int? = nil
    @Relationship(deleteRule: .nullify) var journalEntries: [JournalEntry]?
    
//    let id: String
//    let healthCategory: String // hipo - hiper - sanatos
//    let activityCategory: String // text - imagini - pasi
//    let stringContent: String
    
    init(id: String = "", healthCategory: String = "", activityCategory: String = "", stringContent: String = "", minImageCount: Int? = nil) {
        self.id = id
        self.healthCategory = healthCategory
        self.activityCategory = activityCategory
        self.stringContent = stringContent
        self.minImageCount = minImageCount
    }
}
