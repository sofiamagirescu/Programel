//
//  Quote.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import Foundation

struct Quote: Identifiable, Equatable {
    var id: String
    var quote: String
    var person: String
}
