//
//  Causes.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 22.06.2024.
//

import SwiftData
import Foundation

@Model
class Cause: Identifiable, Equatable {
    var id = UUID()
    let name: String = ""
    @Relationship(deleteRule: .nullify) var journalEntries: [JournalEntry]?
    
    init(name: String = "") {
        self.name = name
    }
    
    // Equatable conformance
    static func == (lhs: Cause, rhs: Cause) -> Bool {
        return lhs.id == rhs.id && lhs.name == rhs.name
    }
}

struct CausesData {
    let causes: [Cause] = [
        Cause(name: "Sănătatea"),
        Cause(name: "Fitness-ul"),
        Cause(name: "Self-Care-ul"),
        Cause(name: "Hobby-urile"),
        Cause(name: "Propria Persoană"),
        Cause(name: "Conexiunea Spirituală"),
        Cause(name: "Comunitatea"),
        Cause(name: "Familia"),
        Cause(name: "Prietenii"),
        Cause(name: "Partenerul/a"),
        Cause(name: "Responsabilitățile"),
        Cause(name: "Școala"),
        Cause(name: "Vremea"),
        Cause(name: "Evenimentele Actuale"),
        Cause(name: "Banii")
    ]
}
