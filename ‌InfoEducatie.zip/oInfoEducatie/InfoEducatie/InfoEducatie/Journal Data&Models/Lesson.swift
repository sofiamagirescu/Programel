//
//  Lesson.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 26.07.2024.
//

import SwiftData
import Foundation

@Model
class Lesson: Identifiable {
    var id: String = ""
    var title: String = ""
    var about: String = ""
    var urlString: String = ""
    var emotionTag: String? = nil
    var healthStateTag: String? = nil
    @Relationship(deleteRule: .nullify) var journalEntries: [JournalEntry]?
    
//    let id: String
//    let title: String
//    let about: String
//    let urlString: String
    
    init(id: String = "", title: String = "", about: String = "", urlString: String = "", emotionTag: String? = nil, healthStateTag: String? = nil) {
        self.id = id
        self.title = title
        self.about = about
        self.urlString = urlString
        self.emotionTag = emotionTag
        self.healthStateTag = healthStateTag
    }
}
