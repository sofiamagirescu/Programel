//
//  HealthStatus.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import Foundation

enum HealthCategory: String {
    case hipo = "hipo"
    case hiper = "hiper"
    case sanatos = "sanatos"
}
