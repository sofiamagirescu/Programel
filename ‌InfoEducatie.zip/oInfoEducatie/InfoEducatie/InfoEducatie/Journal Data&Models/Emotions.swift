//
//  Emotions.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 22.06.2024.
//

import SwiftData
import SwiftUI

@Model
class Emotion: Identifiable, Equatable {
    var id = UUID()
    var name: String = ""
    var colorName: String = ""
    @Relationship(deleteRule: .nullify) var journalEntries: [JournalEntry]?
    
    init(name: String = "", colorName: String = "") {
        self.name = name
        self.colorName = colorName
    }
    
    // Equatable conformance
    static func == (lhs: Emotion, rhs: Emotion) -> Bool {
        return lhs.id == rhs.id && lhs.name == rhs.name && lhs.colorName == rhs.colorName
    }
}

struct EmotionsData {
    let emotions = [
        Emotion(name: "Iubitor", colorName: "Iubitor"),
        Emotion(name: "Trist", colorName: "Trist"),
        Emotion(name: "Recunoscător", colorName: "Recunoscator"),
        Emotion(name: "Plin de Speranță", colorName: "Plin de speranta"),
        Emotion(name: "Calm", colorName: "Calm"),
        Emotion(name: "Îngrijorat", colorName: "Ingrijorat"),
        Emotion(name: "Fericit", colorName: "Fericit"),
        Emotion(name: "Furios", colorName: "Furios"),
        Emotion(name: "Frustrat", colorName: "Frustrat"),
        Emotion(name: "Entuziasmat", colorName: "Entuziasmat"),
        Emotion(name: "Anxios", colorName: "Anxios"),
        Emotion(name: "Uimit", colorName: "Uimit"),
    ]
}
