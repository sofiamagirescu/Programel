//
//  JournalEntry.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 22.06.2024.
//

import SwiftData
import SwiftUI

@Model
class JournalEntry: Identifiable {
    var id = UUID()
    var summary: String = ""
    var date: Date = Date()
    @Relationship(deleteRule: .cascade) var emotions: [Emotion]?
    @Relationship(deleteRule: .cascade) var causes: [Cause]?
    @Relationship(deleteRule: .cascade) var selectedTips: [String: [Tip]]?
    
    var challenge: Challenge?
    var isChallengeCompleted: Bool = false
    var challengeExperienceString: String? = nil
    var challengeExperienceImages: [Data]? = nil
    
    var lesson: Lesson?
    
    init(
        summary: String = "",
        date: Date = .now,
        emotions: [Emotion]? = nil,
        causes: [Cause]? = nil,
        selectedTips: [String: [Tip]]? = nil,
        
        challenge: Challenge? = nil,
        lesson: Lesson? = nil
    ) {
        self.summary = summary
        self.date = date
        self.emotions = emotions
        self.causes = causes
        self.selectedTips = selectedTips
        
        self.challenge = challenge
        self.lesson = lesson
    }
    
    static func addEntry(
        modelContext: ModelContext,
        summary: String,
        date: Date,
        emotions: [Emotion],
        causes: [Cause],
        selectedTips: [String: [Tip]],
        lesson: Lesson,
        challenge: Challenge
    ) {
        for emotion in emotions {
            modelContext.insert(emotion)
        }
        
        for cause in causes {
            modelContext.insert(cause)
        }

        let newEntry = JournalEntry(
            summary: summary,
            date: date,
            emotions: emotions,
            causes: causes,
            selectedTips: selectedTips,
            challenge: challenge,
            lesson: lesson
        )
        
        modelContext.insert(newEntry)
        
        // Relatie bidirectionala
        for emotion in emotions {
            if emotion.journalEntries == nil {
                emotion.journalEntries = [newEntry]
            } else {
                emotion.journalEntries?.append(newEntry)
            }
        }
        
        for cause in causes {
            if cause.journalEntries == nil {
                cause.journalEntries = [newEntry]
            } else {
                cause.journalEntries?.append(newEntry)
            }
        }
    }
}
