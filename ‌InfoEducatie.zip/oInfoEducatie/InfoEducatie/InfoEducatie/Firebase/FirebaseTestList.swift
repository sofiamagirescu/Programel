//
//  FirebaseTestList.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 26.07.2024.
//

import SwiftUI

struct FirebaseTestList: View {
    @StateObject private var viewModel = FirebaseViewModel()
    @State private var isLoading = true
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {
                    ForEach(viewModel.lessons) { lesson in
                        VStack(spacing: 12) {
                            
                            if lesson.healthStateTag != nil || lesson.emotionTag != nil {
                                HStack(spacing: 16) {
                                    Text(lesson.healthStateTag ?? "")
                                    Text(lesson.emotionTag ?? "")
                                }
                            }
                            
                            VideoCardView(
                                showPlayerInAnotherView: true,
                                title: lesson.title,
                                description: lesson.about,
                                urlString: lesson.urlString
                            )
                            Divider()
                        }
                    }
//                    ForEach(viewModel.challenges) { challenge in
//                        DailyChallangeView(
//                            healthCategory: challenge.healthCategory,
//                            activityCategory: challenge.activityCategory,
//                            challangeText: challenge.stringContent
//                        )
//                    }
                }
                .padding(20)
            }
            .refreshable {
                viewModel.getData()
            }
            .navigationTitle("Biblioteca")
        }
        .onChange(of: viewModel.lessons) {
            if !viewModel.lessons.isEmpty {
                isLoading = false
            }
        }
        .overlay {
            if isLoading {
                ProgressView()
            }
        }
    }
}

#Preview {
    FirebaseTestList()
        .modelContainer(previewContainer)
}
