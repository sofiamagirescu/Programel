//
//  ViewModel.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 24.02.2024.
//

import Foundation
import Firebase

class FirebaseViewModel: ObservableObject {
    @Published var challenges = [Challenge]()
    @Published var lessons = [Lesson]()
    @Published var quizQuestions = [QuizQuestion]()
    
    @Published var quotes = [Quote]()
    
    init() {
        getData()
    }
    
    func getData() {
        let db = Firestore.firestore()
        
        db.collection("provocari").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching links: \(error)")
                return
            }
            
            guard let snapshot = snapshot else { return }
            DispatchQueue.main.async {
                self.challenges = snapshot.documents.compactMap { document in
                    let id = document.documentID
                    let healthCategory = document.get("healthCategory") as? String ?? "Eroare"
                    let activityCategory = document.get("activityCategory") as? String ?? "Eroare"
                    let stringContent = document.get("stringContent") as? String ?? "Eroare"
                    let minImageCount = document.get("minImageCount") as? Int?
                    
                    return Challenge(
                        id: id,
                        healthCategory: healthCategory,
                        activityCategory: activityCategory,
                        stringContent: stringContent,
                        minImageCount: minImageCount ?? nil
                    )
                }
                
                self.updateSampleChallenge()
            }
        }
        
        db.collection("videouri").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching links: \(error)")
                return
            }
            
            guard let snapshot = snapshot else { return }
            DispatchQueue.main.async {
                self.lessons = snapshot.documents.compactMap { document in
                    let id = document.documentID
                    let title = document.get("title") as? String ?? "Eroare"
                    let about = document.get("about") as? String ?? "Eroare"
                    let urlString = document.get("urlString") as? String ?? "Eroare"
                    
                    var emotionTag: String? {
                        if document.get("emotionTag") as? String ?? "Eroare" != "nil" {
                            return document.get("emotionTag") as? String ?? "Eroare"
                        } else {
                            return nil
                        }
                    }
                    var healthStateTag: String? {
                        if document.get("healthStateTag") as? String ?? "Eroare" != "nil" {
                            return document.get("healthStateTag") as? String ?? "Eroare"
                        } else {
                            return nil
                        }
                    }
                    
                    return Lesson(
                        id: id,
                        title: title,
                        about: about,
                        urlString: urlString,
                        emotionTag: emotionTag,
                        healthStateTag: healthStateTag
                    )
                }
                
                self.updateSampleLesson()
            }
        }
        
        db.collection("intrebariQuiz").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching links: \(error)")
                return
            }
            
            guard let snapshot = snapshot else { return }
            DispatchQueue.main.async {
                self.quizQuestions = snapshot.documents.compactMap { document in
                    let id = document.documentID
                    let category = document.get("category") as? String ?? "Eroare"
                    let question = document.get("question") as? String ?? "Eroare"
                    
                    return QuizQuestion(
                        id: id,
                        category: category,
                        question: question
                    )
                }
            }
        }
        
        db.collection("citate").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching links: \(error)")
                return
            }
            
            guard let snapshot = snapshot else { return }
            DispatchQueue.main.async {
                self.quotes = snapshot.documents.compactMap { document in
                    let id = document.documentID
                    let quote = document.get("quote") as? String ?? "Eroare"
                    let person = document.get("person") as? String ?? "Eroare"
                    
                    return Quote(
                        id: id,
                        quote: quote,
                        person: person
                    )
                }
                
                self.updateSampleChallenge()
            }
        }
    }
    
    func updateSampleLesson() {
        guard let lesson = lessons.first(where: { $0.id == "hOXyK4DlAxRbWW2xS3LA" }) else { return }
        guard let latestEntry = JournalEntry.sampleEntries.last else { return }
        
        latestEntry.lesson = lesson
    }
    
    func updateSampleChallenge() {
        guard let challange = challenges.first(where: { $0.id == "zuz7HSx4FE8zCz3w5spL" }) else { return }
        guard let latestEntry = JournalEntry.sampleEntries.last else { return }
        
        latestEntry.challenge = challange
    }
}
