//
//  SampleTips.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 02.07.2024.
//

import Foundation

extension Tip {
    static let sampleTips = [
        [
            Tip(index: 1, title: "Titlu 1", body: "Corp 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 2, title: "Titlu 2", body: "Corp 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 3, title: "Titlu 3", body: "Corp 3. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 4, title: "Titlu 4", body: "Corp 4. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 5, title: "Titlu 5", body: "Corp 5. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 6, title: "Titlu 6", body: "Corp 6. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
        ],
        [
            Tip(index: 1, title: "Titlu 1", body: "Corp 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 2, title: "Titlu 2", body: "Corp 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")
        ],
        [
            Tip(index: 1, title: "Titlu 1", body: "Corp 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 2, title: "Titlu 2", body: "Corp 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 3, title: "Titlu 3", body: "Corp 3. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 4, title: "Titlu 4", body: "Corp 4. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 5, title: "Titlu 5", body: "Corp 5. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 6, title: "Titlu 6", body: "Corp 6. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
        ],
        [
            Tip(index: 1, title: "Titlu 1", body: "Corp 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."),
            Tip(index: 2, title: "Titlu 2", body: "Corp 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")
        ]
    ]
}
