//
//  SampleMessages.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 22.06.2024.
//

import Foundation

extension ChatMessage {
//    static let sampleMessages = [
//        ChatMessage(id: UUID().uuidString, content: "Salut! Sunt aici sa te ajut.", dateCreated: Date(), sender: .gpt),
//        ChatMessage(id: UUID().uuidString, content: "Buna. Da-mi niste sfaturi pentru Time Management.", dateCreated: Date(), sender: .user),
//        ChatMessage(id: UUID().uuidString, content: """
//        Sigur, Calin! Time management-ul este esențial pentru a-ți menține echilibrul și a te simți bine.
//        Iată câteva sfaturi care ar putea să te ajute:
//        @TITLE@
//        ***Sfaturi pentru Time Management***
//        @LIST@
//        1. **Prioritizează-ți sarcinile** - Folosește matricea Eisenhower pentru a decide ce este urgent și important.
//        2. **Setează obiective clare** - Definește-ți obiective specifice, măsurabile, realizabile, relevante și limitate în timp (SMART).
//        3. **Folosește un calendar sau o agendă** - Planifică-ți ziua în avans și alocă timp pentru fiecare activitate.
//        4. **Folosește AAAAAAAAAA** - Planifică-ți ziua în avans și alocă timp pentru fiecare activitate doar ca textul asta e diferit.
//        5. **TITLU gyuefhjfeciuh** - hubjefdkiugfvbjwdknshugyhvbenw msdjkuhbjfnd scmjkxhjbefdn msjhe
//        6. **hbjeasfhuefhuwefhu* - uyteqrgjtugjhfdahjgfvgyvfuwbhjgskhjbkjesghkegruhjkdergjhgrdvefhdjrefghdfgrvhjbfdbhjgdfvhjbdfrvhdfrvyfr
//        @LIST@
//        Alte informații care nu trebuie incluse.
//        """, dateCreated: Date(), sender: .gpt),
//        ChatMessage(id: UUID().uuidString, content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.", dateCreated: Date(), sender: .user),
//        ChatMessage(id: UUID().uuidString, content: "poftim", dateCreated: Date(), sender: .gpt)
//    ]
    
    static let sampleMessages = [
        ChatMessage(id: UUID().uuidString, content: """
Salut, Dorel! Am înțeles că te simți cam prost azi. Hai să vedem cum putem să ne simțim mai bine.
Ce crezi că te-a deranjat cel mai tare astăzi? A fost ceva anume care ți-a dat starea asta?
""", dateCreated: Date(), sender: .gpt),
        ChatMessage(id: UUID().uuidString, content: "Da, ma simt foarte anxios recent si nu stiu exact de ce...", dateCreated: Date(), sender: .user),
        ChatMessage(id: UUID().uuidString, content: """
Înțeleg, Dorel. Anxietatea poate apărea din mai multe motive și uneori e greu să identifici exact sursa. Hai să vedem cum o putem gestiona.
@TITLE@
Sfaturi pentru a reduce anxietatea
@LIST@
1. **Respirație profundă** - Încearcă tehnici de respirație pentru a-ți calma mintea și corpul.
2. **Mișcare fizică** - Chiar și o plimbare scurtă poate ajuta la reducerea anxietății.
3. **Pauze regulate** - Ia pauze regulate de la studiu și încearcă să te relaxezi.
4. **Discuții cu prietenii** - Vorbește cu prietenii despre cum te simți; suportul lor poate fi de mare ajutor.
5. **Jurnal** - Scrie-ți gândurile și sentimentele într-un jurnal; acest lucru te poate ajuta să procesezi mai bine ceea ce simți.
6. **Hidratare și alimentație** - Asigură-te că bei suficientă apă și mănânci alimente sănătoase.
@LIST@
Cum ți se par aceste idei? Crezi că vreuna dintre ele ar putea fi de ajutor?
""", dateCreated: Date(), sender: .gpt),
        ChatMessage(id: UUID().uuidString, content: "Si daca nu am cum sa am pauze de la studiu?", dateCreated: Date(), sender: .user),
        ChatMessage(id: UUID().uuidString, content: """
Înțeleg, Dorel. Uneori programul e foarte încărcat și pare imposibil să iei pauze. Hai să vedem cum putem să îți facem programul mai suportabil chiar și fără pauze lungi.
@TITLE@
Strategii pentru gestionarea stresului academic fără pauze lungi
@LIST@
1. **Micro-pauze** - Chiar și 5 minute de pauză la fiecare oră pot face o diferență. Încearcă să te ridici și să te întinzi sau să faci câțiva pași prin cameră.
2. **Tehnica Pomodoro** - Studiază intens timp de 25 de minute, apoi ia o pauză scurtă de 5 minute. Repetă acest ciclu pentru a-ți menține concentrarea și a evita oboseala.
3. **Alternarea sarcinilor** - Schimbă tipul de activitate pe care o faci la fiecare oră sau două. De exemplu, treci de la citit la rezolvat probleme pentru a-ți diversifica activitatea și a reduce monotonia.
4. **Relaxare activă** - Încearcă exerciții de stretching sau de respirație profundă între sarcini. Acestea nu iau mult timp și te pot ajuta să te relaxezi.
5. **Meditație scurtă** - Încearcă sesiuni scurte de meditație ghidată (3-5 minute) pentru a-ți calma mintea.
6. **Hidratare și gustări sănătoase** - Ține lângă tine o sticlă de apă și gustări sănătoase pentru a te menține energizat.
@LIST@
Ce zici? Crezi că poți integra unele dintre aceste strategii în rutina ta de studiu?
""", dateCreated: Date(), sender: .gpt),
    ]
}
