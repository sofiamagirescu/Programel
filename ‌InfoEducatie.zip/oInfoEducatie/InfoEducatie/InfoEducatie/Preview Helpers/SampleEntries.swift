//
//  SampleEntries.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 02.07.2024.
//

import Foundation

extension JournalEntry {
    static let sampleEntries = [
        
        JournalEntry(
            summary: """
Astăzi am avut o zi destul de grea. M-am trezit obosit și nu am avut energia necesară pentru a face toate lucrurile pe care mi le-am propus. La școală, lucrurile au fost destul de intense, iar profesorul a anunțat un nou proiect care mă stresează foarte mult. Am discutat cu colegii mei despre acest lucru și m-am simțit puțin mai bine, dar totuși anxietatea rămâne. Am încercat să mă relaxez ascultând muzică și făcând o plimbare scurtă după școală, dar nu a fost suficient.
""",
            date: Calendar.current.date(byAdding: .day, value: -12, to: Date())!,
            emotions: [EmotionsData().emotions[8], EmotionsData().emotions[5], EmotionsData().emotions[10], EmotionsData().emotions[2]],
            causes: [CausesData().causes[11], CausesData().causes[4]],
            selectedTips: [
                "Sfaturi pentru gestionarea stresului": [
                    Tip(index: 1, title: "Respirație profundă", body: "Respiră adânc și lent pentru a-ți calma mintea. Încearcă să faci acest lucru timp de câteva minute într-un loc liniștit."),
                    Tip(index: 5, title: "Discuții cu prietenii", body: "Vorbește cu prietenii despre cum te simți. Este important să îți exprimi emoțiile și să primești sprijin."),
                    Tip(index: 8, title: "Ascultă muzică", body: "Ascultă muzica preferată pentru a te relaxa. Muzica poate avea un efect calmant și poate ajuta la reducerea stresului.")
                ],
                "Tehnici de relaxare": [
                    Tip(index: 3, title: "Meditație ghidată", body: "Încearcă o sesiune de meditație ghidată. Există multe aplicații care oferă meditații ghidate pentru reducerea stresului."),
                    Tip(index: 6, title: "Exerciții fizice ușoare", body: "Fă exerciții fizice ușoare, cum ar fi stretching sau yoga. Acestea pot ajuta la reducerea tensiunii acumulate în corp.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi a fost o zi mai bună. Am reușit să aplic tehnica Pomodoro pentru a mă organiza mai bine și am observat că micile pauze între sesiuni de studiu chiar ajută. Am avut și o discuție bună cu un prieten apropiat, ceea ce mi-a ridicat moralul. De asemenea, am făcut o plimbare lungă în parc și m-am simțit mult mai relaxat. Vremea frumoasă a contribuit la starea mea de bine.
""",
            date: Calendar.current.date(byAdding: .day, value: -11, to: Date())!,
            emotions: [EmotionsData().emotions[6], EmotionsData().emotions[4], EmotionsData().emotions[0]],
            causes: [CausesData().causes[7], CausesData().causes[12]],
            selectedTips: [
                "Tehnici de productivitate": [
                    Tip(index: 7, title: "Tehnica Pomodoro", body: "Folosește tehnica Pomodoro pentru a-ți gestiona timpul de studiu. Fă pauze scurte de 5 minute după fiecare sesiune de 25 de minute."),
                    Tip(index: 4, title: "Planificare zilnică", body: "Planifică-ți ziua în avans pentru a te organiza mai bine. Notează-ți sarcinile și prioritizează-le."),
                    Tip(index: 3, title: "Pauze regulate", body: "Ia pauze regulate de la studiu și încearcă să te relaxezi. Fă o plimbare scurtă sau întinde-te pentru câteva minute.")
                ],
                "Sfaturi pentru bunăstare mentală": [
                    Tip(index: 2, title: "Jurnalizare", body: "Scrie într-un jurnal despre cum te simți și ce ai realizat. Jurnalizarea te poate ajuta să îți clarifici gândurile și să îți reduci anxietatea."),
                    Tip(index: 9, title: "Hidratare", body: "Asigură-te că bei suficientă apă pe parcursul zilei. Deshidratarea poate contribui la sentimente de oboseală și stres.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi am avut o zi agitată, dar productivă. Am fost foarte concentrat pe sarcinile mele și am reușit să termin multe dintre ele. Totuși, simt că am neglijat puțin partea de relaxare. Am avut doar câteva pauze scurte și am început să simt oboseala acumulată. După-amiaza am decis să fac o sesiune de yoga scurtă, ceea ce m-a ajutat să mă destind și să-mi recâștig energia.
""",
            date: Calendar.current.date(byAdding: .day, value: -9, to: Date())!,
            emotions: [EmotionsData().emotions[8], EmotionsData().emotions[5], EmotionsData().emotions[3]],
            causes: [CausesData().causes[11], CausesData().causes[3]],
            selectedTips: [
                "Sfaturi pentru echilibru între muncă și viață": [
                    Tip(index: 4, title: "Yoga", body: "O sesiune scurtă de yoga poate ajuta la reducerea stresului. Încearcă să practici yoga dimineața sau seara pentru a-ți relaxa corpul și mintea."),
                    Tip(index: 9, title: "Meditație", body: "Meditează câteva minute pentru a-ți calma mintea. Începe cu meditații scurte de 5-10 minute și crește treptat durata."),
                    Tip(index: 2, title: "Mișcare fizică", body: "Chiar și o plimbare scurtă poate ajuta la reducerea anxietății. Încearcă să faci mișcare fizică în fiecare zi pentru a te menține activ și sănătos.")
                ],
                "Tehnici de relaxare": [
                    Tip(index: 5, title: "Respirație profundă", body: "Fă exerciții de respirație profundă pentru a te relaxa. Inspiră lent pe nas și expiră încet pe gură, concentrându-te pe respirație."),
                    Tip(index: 3, title: "Aromaterapie", body: "Folosește uleiuri esențiale pentru aromaterapie. Lavanda și mușețelul sunt cunoscute pentru proprietățile lor calmante.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi am avut o zi destul de relaxantă. Am petrecut timp cu familia și am fost la un picnic. A fost plăcut să petrec timp în natură și să mă deconectez de la grijile cotidiene. Am simțit că acest timp petrecut în aer liber m-a ajutat să mă relaxez și să-mi limpezesc mintea. Seara am citit o carte bună și m-am simțit foarte liniștit.
""",
            date: Calendar.current.date(byAdding: .day, value: -8, to: Date())!,
            emotions: [EmotionsData().emotions[4], EmotionsData().emotions[6], EmotionsData().emotions[1]],
            causes: [CausesData().causes[7], CausesData().causes[12]],
            selectedTips: [
                "Activități recreative": [
                    Tip(index: 10, title: "Cititul", body: "Citește o carte bună pentru a te relaxa. Alegerea unei cărți interesante te poate ajuta să te deconectezi de la stres."),
                    Tip(index: 5, title: "Discuții cu familia", body: "Petrece timp de calitate cu familia. Discuțiile și activitățile împreună pot întări legăturile și pot oferi sprijin emoțional."),
                    Tip(index: 2, title: "Mișcare fizică", body: "Chiar și o plimbare scurtă poate ajuta la reducerea anxietății. Petrece timp în aer liber pentru a te revigora.")
                ],
                "Sfaturi pentru sănătate mentală": [
                    Tip(index: 8, title: "Jurnalizare", body: "Scrie despre experiențele tale zilnice și cum te simți în jurnalul tău. Acest lucru te poate ajuta să îți clarifici gândurile și emoțiile.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi a fost o zi destul de stresantă. Am avut multe de făcut la școală și am simțit presiunea termenelor limită. Am reușit să fac față stresului folosind tehnica Pomodoro și am luat pauze scurte pentru a mă destinde. După școală, am făcut o sesiune de meditație scurtă și am simțit cum stresul se reduce treptat.
""",
            date: Calendar.current.date(byAdding: .day, value: -7, to: Date())!,
            emotions: [EmotionsData().emotions[5], EmotionsData().emotions[8], EmotionsData().emotions[2]],
            causes: [CausesData().causes[11], CausesData().causes[4]],
            selectedTips: [
                "Sfaturi pentru reducerea stresului": [
                    Tip(index: 7, title: "Tehnica Pomodoro", body: "Folosește tehnica Pomodoro pentru a-ți gestiona timpul de studiu. Fă pauze scurte de 5 minute după fiecare sesiune de 25 de minute."),
                    Tip(index: 9, title: "Meditație", body: "Meditează câteva minute pentru a-ți calma mintea. Începe cu meditații scurte de 5-10 minute și crește treptat durata."),
                    Tip(index: 6, title: "Hidratare și alimentație", body: "Asigură-te că bei suficientă apă și mănânci alimente sănătoase pentru a menține un nivel optim de energie și concentrare.")
                ],
                "Tehnici de relaxare": [
                    Tip(index: 5, title: "Respirație profundă", body: "Fă exerciții de respirație profundă pentru a te relaxa. Inspiră lent pe nas și expiră încet pe gură, concentrându-te pe respirație."),
                    Tip(index: 3, title: "Aromaterapie", body: "Folosește uleiuri esențiale pentru aromaterapie. Lavanda și mușețelul sunt cunoscute pentru proprietățile lor calmante.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi am avut o zi minunată! Am luat o pauză de la toate grijile academice și am ieșit cu prietenii la un film. A fost o adevărată gură de aer proaspăt și m-am simțit foarte bine să râd și să mă distrez. După film, am mers să mâncăm împreună și am petrecut o seară plăcută discutând despre diverse subiecte.
""",
            date: Calendar.current.date(byAdding: .day, value: -6, to: Date())!,
            emotions: [EmotionsData().emotions[6], EmotionsData().emotions[0], EmotionsData().emotions[3]],
            causes: [CausesData().causes[8], CausesData().causes[9]],
            selectedTips: [
                "Sfaturi pentru bunăstare emoțională": [
                    Tip(index: 5, title: "Discuții cu prietenii", body: "Petrece timp cu prietenii pentru a te simți mai bine. Socializarea poate reduce stresul și poate îmbunătăți starea de spirit."),
                    Tip(index: 11, title: "Activități recreative", body: "Fă activități care îți plac și te relaxează. Poți merge la un film, la teatru sau la un concert."),
                    Tip(index: 10, title: "Socializare", body: "Ieși în oraș și socializează pentru a-ți îmbunătăți starea de spirit. Interacțiunile sociale pot aduce o perspectivă nouă și pozitivă.")
                ],
                "Tehnici de relaxare": [
                    Tip(index: 3, title: "Aromaterapie", body: "Folosește uleiuri esențiale pentru aromaterapie. Lavanda și mușețelul sunt cunoscute pentru proprietățile lor calmante."),
                    Tip(index: 6, title: "Hidratare și alimentație", body: "Asigură-te că bei suficientă apă și mănânci alimente sănătoase pentru a menține un nivel optim de energie și concentrare.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi m-am concentrat pe studiu și am încercat să mă țin de programul meu. Am folosit tehnica Pomodoro și am luat pauze regulate, ceea ce m-a ajutat să rămân productiv. În pauze, am făcut exerciții de respirație și am ascultat muzică relaxantă. Am simțit că am reușit să fiu mai eficient și mai calm în același timp.
""",
            date: Calendar.current.date(byAdding: .day, value: -4, to: Date())!,
            emotions: [EmotionsData().emotions[4], EmotionsData().emotions[6], EmotionsData().emotions[2]],
            causes: [CausesData().causes[11], CausesData().causes[3]],
            selectedTips: [
                "Tehnici de productivitate și relaxare": [
                    Tip(index: 7, title: "Tehnica Pomodoro", body: "Folosește tehnica Pomodoro pentru a-ți gestiona timpul de studiu. Fă pauze scurte de 5 minute după fiecare sesiune de 25 de minute."),
                    Tip(index: 1, title: "Respirație profundă", body: "Respiră adânc și lent pentru a-ți calma mintea. Încearcă să faci acest lucru timp de câteva minute într-un loc liniștit."),
                    Tip(index: 8, title: "Ascultă muzică", body: "Ascultă muzica preferată pentru a te relaxa. Muzica poate avea un efect calmant și poate ajuta la reducerea stresului.")
                ],
                "Sfaturi pentru bunăstare mentală": [
                    Tip(index: 2, title: "Jurnalizare", body: "Scrie într-un jurnal despre cum te simți și ce ai realizat. Jurnalizarea te poate ajuta să îți clarifici gândurile și să îți reduci anxietatea."),
                    Tip(index: 9, title: "Hidratare", body: "Asigură-te că bei suficientă apă pe parcursul zilei. Deshidratarea poate contribui la sentimente de oboseală și stres.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi a fost o zi de odihnă. Am decis să iau o pauză completă de la studiu și să mă dedic activităților care îmi plac. Am petrecut timp citind o carte interesantă și am făcut o plimbare lungă în parc. De asemenea, am avut o sesiune de yoga relaxantă care m-a ajutat să îmi limpezesc mintea și să mă simt revigorat.
""",
            date: Calendar.current.date(byAdding: .day, value: -3, to: Date())!,
            emotions: [EmotionsData().emotions[4], EmotionsData().emotions[6], EmotionsData().emotions[0]],
            causes: [CausesData().causes[3], CausesData().causes[1]],
            selectedTips: [
                "Sfaturi pentru odihnă și recuperare": [
                    Tip(index: 10, title: "Cititul", body: "Citește o carte bună pentru a te relaxa. Alegerea unei cărți interesante te poate ajuta să te deconectezi de la stres."),
                    Tip(index: 4, title: "Yoga", body: "O sesiune scurtă de yoga poate ajuta la reducerea stresului și la îmbunătățirea flexibilității. Încearcă să practici yoga în mod regulat."),
                    Tip(index: 2, title: "Mișcare fizică", body: "Chiar și o plimbare scurtă poate ajuta la reducerea anxietății. Petrece timp în aer liber pentru a te revigora și a-ți limpezi mintea.")
                ],
                "Sfaturi pentru bunăstare mentală": [
                    Tip(index: 8, title: "Jurnalizare", body: "Scrie într-un jurnal despre cum te simți și ce ai realizat. Jurnalizarea te poate ajuta să îți clarifici gândurile și să îți reduci anxietatea."),
                    Tip(index: 9, title: "Hidratare", body: "Asigură-te că bei suficientă apă pe parcursul zilei. Deshidratarea poate contribui la sentimente de oboseală și stres.")
                ]
            ]
        ),
        JournalEntry(
            summary: """
Astăzi mă simt foarte anxios și nu sunt sigur exact de ce. Am vorbit cu asistentul meu personal despre starea mea și am încercat să descompunem ce ar putea cauza această anxietate. Mi-a pus câteva întrebări despre ultimele zile, despre stresul academic și despre vreme. Mi-am dat seama că poate fi un mix de factori: momentele stresante de la școală și poate chiar vremea.
Am primit și câteva sugestii pentru a reduce anxietatea, cum ar fi tehnici de respirație profundă, mișcare fizică și discuții cu prietenii. Totuși, mi-a fost greu să mă gândesc la cum aș putea să fac pauze de la studiu, având un program atât de încărcat.
Asistentul meu mi-a sugerat apoi strategii pentru gestionarea stresului academic fără pauze lungi, cum ar fi micro-pauzele, tehnica Pomodoro, alternarea sarcinilor și meditația scurtă. Aceste idei par mai realizabile și m-au ajutat să văd că pot găsi momente scurte de relaxare chiar și în timpul studiului intens.
M-am simțit ascultat și sprijinit în această conversație, ceea ce m-a ajutat puțin să mă mai liniștesc. Sper că, integrând unele dintre aceste strategii, voi putea să gestionez mai bine stresul și anxietatea în zilele următoare.
""",
            date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!,
            emotions: [EmotionsData().emotions[2], EmotionsData().emotions[8], EmotionsData().emotions[5]],
            causes: [CausesData().causes[3], CausesData().causes[4], CausesData().causes[1], CausesData().causes[7]],
            selectedTips: ["Sfaturi pentru a reduce anxietatea":
            [
                Tip(index: 2, title: "Mișcare fizică", body: "Chiar și o plimbare scurtă poate ajuta la reducerea anxietății."),
                Tip(index: 3, title: "Pauze regulate", body: "Ia pauze regulate de la studiu și încearcă să te relaxezi."),
                Tip(index: 6, title: "Hidratare și alimentație", body: "Asigură-te că bei suficientă apă și mănânci alimente sănătoase.")
            ]
           ]
        ),
        
        
        
        
        JournalEntry(
            summary: """
Astăzi am avut o zi plină de energie pozitivă. Am petrecut timp cu familia și am avut discuții profunde care m-au făcut să mă simt iubit și apreciat. Am gătit împreună și am savurat mâncăruri delicioase. A fost o zi în care am simțit o conexiune profundă cu cei dragi și m-am bucurat de fiecare moment.
""",
            date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!,
            emotions: [EmotionsData().emotions[6], EmotionsData().emotions[0], EmotionsData().emotions[1]],
            causes: [CausesData().causes[7], CausesData().causes[9]],
            selectedTips: [
                "Sfaturi pentru relații sănătoase": [
                    Tip(index: 5, title: "Discuții cu familia", body: "Petrece timp de calitate cu familia. Discuțiile și activitățile împreună pot întări legăturile și pot oferi sprijin emoțional."),
                    Tip(index: 11, title: "Activități recreative", body: "Fă activități care îți plac și te relaxează. Gătitul împreună cu cei dragi poate fi o activitate plăcută și relaxantă."),
                    Tip(index: 10, title: "Socializare", body: "Ieși în oraș și socializează pentru a-ți îmbunătăți starea de spirit. Interacțiunile sociale pot aduce o perspectivă nouă și pozitivă.")
                ],
                "Sfaturi pentru bunăstare emoțională": [
                    Tip(index: 6, title: "Exprimarea recunoștinței", body: "Fii recunoscător pentru lucrurile bune din viața ta. Exprimarea recunoștinței poate îmbunătăți starea de spirit și poate reduce stresul."),
                    Tip(index: 4, title: "Mindfulness", body: "Practică mindfulness pentru a te concentra pe momentul prezent și a reduce anxietatea. Mindfulness-ul te poate ajuta să gestionezi mai bine stresul.")
                ]
            ]
        )
    ]
}
