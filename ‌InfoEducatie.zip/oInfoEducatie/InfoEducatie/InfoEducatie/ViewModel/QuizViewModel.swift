//
//  QuizViewModel.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import Foundation

class QuizViewModel: ObservableObject {
    @Published var curatedQuizQuestions: [QuizQuestion]
    @Published var quizQuestionDictionary: [QuizQuestion: Int]
    @Published var canFinish: Bool = false
    @Published var healthState: String = "optim"
    
    init(
        curatedQuizQuestions: [QuizQuestion] = [],
        quizQuestionDictionary: [QuizQuestion : Int] = [:],
        canFinish: Bool = false,
        healthState: String = "optim"
    ) {
        self.curatedQuizQuestions = curatedQuizQuestions
        self.quizQuestionDictionary = quizQuestionDictionary
        self.canFinish = canFinish
        self.healthState = healthState
    }
    
    func initialize(with quizQuestions: [QuizQuestion], defaultValue: Int = 0) {
        let hipoQuestions = quizQuestions.filter { $0.category == HealthCategory.hipo.rawValue }
        let hyperQuestions = quizQuestions.filter { $0.category == HealthCategory.hiper.rawValue }
        let neutralQuestions = quizQuestions.filter { $0.category == "neutru" }
        
        let curatedQuizQuestions = Array(hipoQuestions.shuffled().prefix(2)) +
                                   Array(hyperQuestions.shuffled().prefix(2)) +
                                   Array(neutralQuestions.shuffled().prefix(2))
        
        self.curatedQuizQuestions = curatedQuizQuestions
        self.quizQuestionDictionary = Dictionary(uniqueKeysWithValues: curatedQuizQuestions.map { ($0, defaultValue) })
    }
    
    func updateQuizQuestionDictionary(for question: QuizQuestion, with value: Int) {
        quizQuestionDictionary[question] = value
        canFinish = quizQuestionDictionary.allSatisfy { $0.value >= 1 && $0.value <= 10 }
        if canFinish {
            determineHealthState()
        }
    }
    
    func determineHealthState() {
        var x = 0

        for (question, response) in quizQuestionDictionary {
            switch question.category {
            case HealthCategory.hipo.rawValue:
                if response >= 1 && response <= 5 {
                    x -= 1
                }
            case HealthCategory.hiper.rawValue:
                if response >= 6 && response <= 10 {
                    x += 1
                }
            case "neutru":
                if response >= 1 && response <= 3 {
                    x -= 1
                }
                if response >= 7 && response <= 10 {
                    x += 1
                }
            default:
                break
            }
        }

        if x < 0 {
            self.healthState = HealthCategory.hipo.rawValue
        } else if x == 0 {
            self.healthState = HealthCategory.sanatos.rawValue
        } else {
            self.healthState = HealthCategory.hiper.rawValue
        }
    }
}
