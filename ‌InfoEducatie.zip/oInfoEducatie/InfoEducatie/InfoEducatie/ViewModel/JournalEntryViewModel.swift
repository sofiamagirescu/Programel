//
//  JournalEntryViewModel.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import SwiftUI
import Combine

class JournalEntryViewModel: ObservableObject {
//    @Published var journalEntries: [JournalEntry] = []
    
    func saveClassifiedImages(for entry: JournalEntry, classifiedImages: [ClassifiedImage]) {
        let uiImages = classifiedImages.compactMap { $0.image.asUIImage() }
        let imageDataArray = uiImages.compactMap { $0.jpegData(compressionQuality: 1.0) }
        entry.challengeExperienceImages = imageDataArray
    }

    func loadImages(for entry: JournalEntry) -> [UIImage]? {
        guard let imageDataArray = entry.challengeExperienceImages else { return nil }
        return imageDataArray.compactMap { UIImage(data: $0) }
    }
    
    func recommendLessons(selectedEmotions: [Emotion], healthState: String, lessons: [Lesson]) -> [Lesson] {
        var lessonsWithSelectedEmotions: [Lesson] = []
        for emotion in selectedEmotions {
            let newLessonsWithEmotion = lessons.filter {
                $0.emotionTag?.lowercased() == emotion.name.lowercased()
            }
            lessonsWithSelectedEmotions.append(contentsOf: newLessonsWithEmotion)
        }
        
        let lessonsWithHealthState = lessons.filter {
            $0.healthStateTag?.lowercased().contains(healthState.lowercased()) ?? false
        }
        let relevantLessons = lessonsWithSelectedEmotions + lessonsWithHealthState
        
        if !relevantLessons.isEmpty {
            return relevantLessons.shuffled()
        } else {
            return lessons.shuffled()
        }
    }
    
    func recommendChallenges(healthState: String, challenges: [Challenge]) -> [Challenge] {
        let relevantChallenges = challenges.filter {
            $0.healthCategory.lowercased() == healthState.lowercased()
        }
        
        if !relevantChallenges.isEmpty {
            return relevantChallenges.shuffled()
        } else {
            return challenges.shuffled()
        }
    }
}
