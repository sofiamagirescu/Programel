//
//  TestRecommendationsList.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import SwiftUI

struct TestRecommendationsList: View {
    @StateObject private var viewModel = FirebaseViewModel()
    @State private var isLoading = true
    
    @State private var recommendedLessons: [Lesson] = []
    
    var body: some View {
            
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {
                    ForEach(recommendedLessons) { lesson in
                        VStack(spacing: 18) {
                            
                            if lesson.healthStateTag != nil || lesson.emotionTag != nil {
                                HStack(spacing: 16) {
                                    Text(lesson.healthStateTag ?? "")
                                    Text(lesson.emotionTag ?? "")
                                }
                            }
                            
                            VideoCardView(
                                showPlayerInAnotherView: true,
                                title: lesson.title,
                                description: lesson.about,
                                urlString: lesson.urlString
                            )
                            Divider()
                                .padding(.bottom)
                        }
                    }
//                    ForEach(viewModel.challenges) { challenge in
//                        DailyChallangeView(
//                            healthCategory: challenge.healthCategory,
//                            activityCategory: challenge.activityCategory,
//                            challangeText: challenge.stringContent
//                        )
//                    }
                }
                .padding(20)
            }
            .refreshable {
                viewModel.getData()
            }
            .navigationTitle("Biblioteca")
        }
        .onChange(of: viewModel.lessons) {
            if !viewModel.lessons.isEmpty {
                isLoading = false
                
                recommendedLessons = JournalEntryViewModel().recommendLessons(
                    selectedEmotions: [
                        EmotionsData().emotions[10]
                    ],
                    healthState: HealthCategory.hipo.rawValue,
                    lessons: viewModel.lessons
                )
            }
        }
        .overlay {
            if isLoading {
                ProgressView()
            }
        }
    }
}

#Preview {
    TestRecommendationsList()
        .modelContainer(previewContainer)
}
