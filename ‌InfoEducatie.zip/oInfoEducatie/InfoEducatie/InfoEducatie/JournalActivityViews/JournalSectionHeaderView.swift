//
//  JournalSectionHeaderView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 24.07.2024.
//

import SwiftUI

struct JournalSectionHeaderView: View {
    
    var header: String
    var title: String
    
    var isVisible: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(header)
                .staggeredAppear(isVisible: isVisible, index: 2)
            
            Text(title)
                .font(.custom("DMSerifDisplay-Regular", size: 36))
                .staggeredAppear(isVisible: isVisible, index: 1)
            
            Divider()
                .padding(.vertical, 20)
                .staggeredAppear(isVisible: isVisible, index: 1)
        }
        .frame(maxWidth: MaxWidths().maxStandardWidth)
    }
}
