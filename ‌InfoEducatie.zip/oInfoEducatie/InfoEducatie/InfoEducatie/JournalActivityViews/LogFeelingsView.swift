//
//  LogFeelingsView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 17.07.2024.
//

import SwiftUI

struct LogFeelingsView: View {
    
    var isHeaderVisible: Bool
    
    let limit = 5
    var disabled: Bool {
        emotions.count >= limit
    }
    
    @Binding var emotions: [Emotion]
    var emotionNames: [String] {
        emotions.map { $0.name }
    }
    
    let columns = Array(repeating: GridItem(.flexible()), count: 2)
    
    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 12) {
                
                JournalSectionHeaderView(
                    header: "Mai intai, o intrebare simpla:",
                    title: "Cum te-ai simti astazi, pana acum?",
                    isVisible: isHeaderVisible
                )
                
//                Text("Alege maxim \(limit)")
//                    .padding(.top, -10)
//                    .padding(.bottom, 12)
//                    .font(.subheadline.smallCaps())
//                    .foregroundColor(.secondary)
                
                LazyVGrid(columns: columns, alignment: .leading, spacing: 20) {
                    ForEach(EmotionsData().emotions) { emotion in
                        VStack {
                            ZStack {
                                Circle()
                                    .foregroundColor(Color(emotion.colorName))
                                    .blur(radius: 8)
                                Circle()
                                    .stroke(Color(emotion.colorName), lineWidth: 2)
                                    .brightness(0.32)
                                    .padding(12)
                            }
                            .padding(.horizontal, 32)
                            .padding(.vertical, 42)
                            
                            Text(emotion.name)
                                .font(.title3)
                                .fontWeight(.semibold)
                                .multilineTextAlignment(.center)
                                .foregroundColor(.primary)
                                .padding(.horizontal, 20)
                            Spacer(minLength: 0)
                        }
                        .padding(.vertical, 24)
                        .background(
                            Color(.systemBackground)
                                .opacity(emotions == [] ? 1 : 0.8)
                        )
                        .cornerRadius(12)
                        .shadow(
                            color:
                                emotions == [] ?
                                Color.primary
                                    .opacity(0.03)
                                :
                                Color(emotion.colorName)
                                    .opacity(0.1),
                            radius: 16
                        )
                        .overlay(
                            Group {
                                if emotions.contains(where: { $0.name == emotion.name }) {
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color(emotion.colorName), lineWidth: 3)
                                        .animation(.smooth.delay(0.1), value: emotions.count)
                                } else if emotions == [] {
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(
                                            .gray,
                                            lineWidth: 0.2
                                        )
                                }
                            }
                        )
                        .padding(.trailing, 12)
                        .onTapGesture {
                            toggleEmotion(emotion)
                        }
                        
                        .disabled(
                            !emotions.contains(where: { $0.name == emotion.name })
                            && disabled
                        )
                        .opacity(
                            !emotions.contains(where: { $0.name == emotion.name })
                            && disabled ?
                            0.5 : 1
                        )
                    }
                }
                .staggeredAppear(isVisible: isHeaderVisible, index: 0, offset: 0, duration: isHeaderVisible ? 0 : 1.2)
                .padding(.trailing, -12)
            }
            .padding(32)
        }
    }
    
    private func toggleEmotion(_ emotion: Emotion) {
        if let index = emotions.firstIndex(where: { $0.name == emotion.name && $0.colorName == emotion.colorName }) {
            emotions.remove(at: index)
        } else {
            emotions.append(emotion)
        }
    }
}

#Preview {
    ZStack {
        BlurryBackgroundView(
            colors: .constant([
                Color("Furios"),
                Color("Iubitor"),
                Color("Ingrijorat"),
                Color("Fericit")
            ]),
            blurAmmount: 60
        )
        .opacity(0.1)
        
        Color(.systemBackground)
            .opacity(0.8)
            .edgesIgnoringSafeArea(.all)
        
        LogFeelingsView(
            isHeaderVisible: true,
            emotions: .constant([
//                Emotion(name: "Furios", colorName: "Furios"),
//                Emotion(name: "Recunoscator", colorName: "Recunoscator"),
//                Emotion(name: "Ingrijorat", colorName: "Ingrijorat"),
//                Emotion(name: "Fericit", colorName: "Fericit"),
//                Emotion(name: "Anxios", colorName: "Anxios")
            ])
        )
    }
    .modelContainer(previewContainer)
}
