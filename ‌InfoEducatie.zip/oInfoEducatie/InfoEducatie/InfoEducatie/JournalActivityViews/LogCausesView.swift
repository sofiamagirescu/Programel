//
//  LogCausesView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 24.07.2024.
//

import SwiftUI
import SwiftData

struct LogCausesView: View {
    
    var isHeaderVisible: Bool
    var accentColor: Color
    @Binding var selectedCauses: [Cause]
    
    var body: some View {
        VStack(alignment: .center, spacing: 2) {
            
            JournalSectionHeaderView(
                header: "In al doilea rand:",
                title: "Ce ti-a afectat starea sufleteasca astazi?",
                isVisible: isHeaderVisible
            )
            
            ScrollView(showsIndicators: false) {
                VStack {
                    FlowLayout(items: CausesData().causes.map { $0.name }, spacing: 4, content: { text in
                        Button(action: {
                            if let index = selectedCauses.firstIndex(where: { $0.name == text }) {
                                selectedCauses.remove(at: index)
                            } else {
                                selectedCauses.append(Cause(name: text))
                            }
                        }) {
                            Text(text)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(
                                    selectedCauses.contains(where: { $0.name == text })
                                    ? accentColor
                                    : Color.white
                                )
                                .foregroundColor(
                                    selectedCauses.contains(where: { $0.name == text })
                                    ? Color.white
                                    : Color.black
                                )
                                .clipShape(Capsule())
                                .shadow(color: accentColor.opacity(
                                    selectedCauses.contains(where: { $0.name == text }) ? 0 : 0.06
                                ), radius: 12, x: 4, y: 2)
                                .shadow(color: .black.opacity(
                                    selectedCauses.contains(where: { $0.name == text }) ? 0 : 0.04
                                ), radius: 6, x: 4, y: 2)
                        }
                    })
                }
                .padding(6)
            }
            .scrollBounceBehavior(.basedOnSize)
            .mask(
                VStack(spacing: 0) {
                    LinearGradient(colors: [.red.opacity(0), .red], startPoint: .top, endPoint: .bottom).frame(height: 6)
                    Color.red
                    LinearGradient(colors: [.red.opacity(0), .red], startPoint: .bottom, endPoint: .top).frame(height: 6)
                }
            )
        }
    }
}

#Preview {
    ZStack {
        Color(.systemGray6)
            .edgesIgnoringSafeArea(.all)
        
        LogCausesView(
            isHeaderVisible: true, 
            accentColor: .red,
            selectedCauses: .constant([])
        )
        .padding(32)
        .modelContainer(previewContainer)
    }
}
