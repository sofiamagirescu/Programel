//
//  RecommendedContentView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import SwiftUI

struct RecommendedContentView: View {
    var accentColor: Color = .accentColor
    var isHeaderVisible: Bool = true
    
    @EnvironmentObject var firebaseViewModel: FirebaseViewModel
//    @StateObject private var quizViewModel = QuizViewModel()
    
    @Binding var canFinish: Bool
    @Binding var selectedEmotions: [Emotion]
    @Binding var healthState: String
    
    @Binding var recommendedLesson: Lesson?
    @Binding var recommendedChallenge: Challenge?
    
    var body: some View {
        
        ScrollView {
            VStack(alignment: .center, spacing: 12) {
                
                JournalSectionHeaderView(
                    header: "Ultimele, dar si nu cele din urma:",
                    title: "Activitatile tale pentru astazi",
                    isVisible: isHeaderVisible
                )
                
                if recommendedLesson == nil || recommendedChallenge == nil {
                    ProgressView()
                        .frame(height: 320)
                } else {
                    VStack(alignment: .leading, spacing: 28) {
                        Text("Acestea pot fi accesate oricand in sectiunea 'Activitate' din ecranul principal.")
                            .font(.subheadline)
                            .bold()
                            .padding(.horizontal, 8)
                            .padding(.vertical, -4)
                        
                        VideoCardView(
                            showPlayerInAnotherView: false,
                            title: recommendedLesson?.title ?? "Error",
                            description: recommendedLesson?.about ?? "Error",
                            urlString: recommendedLesson?.urlString ?? "",
                            accentColor: accentColor
                        )
                        .fixedSize(horizontal: false, vertical: true)
                        
                        DailyChallangeView(
                            healthCategory: recommendedChallenge?.healthCategory ?? HealthCategory.hipo.rawValue,
                            activityCategory: recommendedChallenge?.activityCategory ?? "text",
                            challangeText: recommendedChallenge?.stringContent ?? "Eroare",
                            isChallengeCompleted: .constant(false),
                            idOfEntryToChange: UUID()
                        )
                        .fixedSize(horizontal: false, vertical: true)
                    }
                    .onAppear {
                        canFinish = true
                    }
                }
            }
            .padding(32)
        }
        .onAppear {
            firebaseViewModel.getData()
        }
        .onChange(of: firebaseViewModel.lessons) {
            withAnimation {
                recommendedLesson = JournalEntryViewModel().recommendLessons(
                    selectedEmotions: selectedEmotions,
                    healthState: healthState,
                    lessons: firebaseViewModel.lessons
                ).first
            }
        }
        .onChange(of: firebaseViewModel.lessons) {
            withAnimation {
                recommendedChallenge = JournalEntryViewModel().recommendChallenges(
                    healthState: healthState,
                    challenges: firebaseViewModel.challenges
                ).first
            }
        }
    }
}

struct RecommendedContentViewPreviewContainer: View {
    @StateObject private var viewModel = FirebaseViewModel()
    
    @State private var canFinish = false
    @State private var healthState = HealthCategory.sanatos.rawValue
    @State private var selectedEmotions: [Emotion] = []
    
    var body: some View {
        ZStack {
            Color(.systemGray6)
                .edgesIgnoringSafeArea(.all)
            RecommendedContentView(
                canFinish: $canFinish,
                selectedEmotions: $selectedEmotions,
                healthState: $healthState,
                recommendedLesson: .constant(Lesson()),
                recommendedChallenge: .constant(Challenge())
            )
        }
//        .onAppear {
//            selectedEmotions = [EmotionsData().emotions[10]]
//        }
        .environmentObject(viewModel)
        .modelContainer(previewContainer)
    }
}

#Preview {
    RecommendedContentViewPreviewContainer()
}
