//
//  QuizView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 27.07.2024.
//

import SwiftUI

struct QuizView: View {
    var accentColor: Color = .accentColor
    var isHeaderVisible: Bool = true
    
    @EnvironmentObject var firebaseViewModel: FirebaseViewModel
    @StateObject private var quizViewModel = QuizViewModel()
    
    @Binding var canFinish: Bool
    @Binding var healthState: String
    
    var body: some View {
        
        ScrollView {
            VStack(alignment: .center, spacing: 12) {
                
                JournalSectionHeaderView(
                    header: "In alta ordine de idei:",
                    title: "A venit timpul pentru quiz-ul zilnic!",
                    isVisible: isHeaderVisible
                )
                
                VStack(alignment: .leading, spacing: 28) {
                    ForEach(Array(quizViewModel.quizQuestionDictionary.keys.sorted(by: { $0.category < $1.category }).enumerated()), id: \.element) { index, question in
                        HStack(spacing: 0) {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Intrebarea \(index + 1)")
                                    .foregroundColor(.secondary)
                                    .font(.subheadline)
                                Text("\(question.question) (pe o scara de la 1 la 10)")
                                
                                let value = quizViewModel.quizQuestionDictionary[question] ?? 0
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 12) {
                                        ForEach(1..<11) { i in
                                            Button(action: {
                                                withAnimation(.smooth) {
                                                    if value == i {
                                                        quizViewModel.updateQuizQuestionDictionary(for: question, with: 0)
                                                    } else {
                                                        quizViewModel.updateQuizQuestionDictionary(for: question, with: i)
                                                    }
                                                }
                                            }) {
                                                Text("\(i)")
                                                    .font(.headline)
                                                    .frame(width: 42, height: 42)
                                                    .background(value == i ? accentColor : Color(.systemBackground))
                                                    .foregroundColor(value == i ? .white : accentColor)
                                                    .clipShape(Circle())
                                                    .shadow(color: .primary.opacity(0.1), radius: 6, x: 2, y: 3)
                                                    .tag(i)
                                            }
                                        }
                                    }
                                }
                                .scrollClipDisabled()
                                .padding(.top, 16)
                            }
                            
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 28)
                        .padding(.vertical, 24)
                        .background(Color(.systemBackground))
                        .cornerRadius(12)
                        .shadow(color: .primary.opacity(0.1), radius: 16, x: 6, y: 4)
                    }
                }
            }
            .overlay {
                if canFinish {
                    ZStack {
                        Text(healthState)
                            .background(Color.red)
                    }
                }
            }
            .padding(32)
        }
        .onAppear {
            quizViewModel.initialize(with: firebaseViewModel.quizQuestions)
        }
        .onChange(of: firebaseViewModel.quizQuestions) {
            quizViewModel.initialize(with: firebaseViewModel.quizQuestions)
        }
        .onChange(of: quizViewModel.canFinish) {
            canFinish = quizViewModel.canFinish
        }
        .onChange(of: quizViewModel.healthState) {
            healthState = quizViewModel.healthState
        }
    }
}

struct QuizViewPreviewContainer: View {
    @StateObject private var viewModel = FirebaseViewModel()
    
    @State private var canFinish = false
    @State private var healthState = "optim"
    
    var body: some View {
        ZStack {
            Color(.systemGray6)
                .edgesIgnoringSafeArea(.all)
            QuizView(
                canFinish: $canFinish,
                healthState: $healthState
            )
        }
        .environmentObject(viewModel)
        .modelContainer(previewContainer)
    }
}

#Preview {
    QuizViewPreviewContainer()
}
