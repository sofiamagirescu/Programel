//
//  ChatView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 17.06.2024.
//

import SwiftUI
import Combine

struct ChatView: View {
    
    @EnvironmentObject var openAIService: OpenAIService
    
    @EnvironmentObject var userInfo: UserInfo
    
    @State var chatMessages: [ChatMessage]
    var accentColor: Color
    
    @Binding var emotions: [Emotion]
    @Binding var causes: [Cause]
    
    @Binding var organizedSelectedTips: [String: [Tip]]
    
    @State private var load = false
    
    @State private var message = ""
    @State private var showSendButton = false
    
    var prompt: String {
        "SISTEM: Esti un asistent personal pentru utilizator. Numele utilizatorului este \(UserInfo().userFirstName) \(UserInfo().userFirstName) (mai intai prenumele, apoi numele de familie) si foloseste pronume \(UserInfo().userPronouns). Pe parcursul zilei, utilizatorul s-a simtit \(emotions.map { $0.name }.joined(separator: " + ").lowercased()). Factorii ce i-au afectat in mod pozitiv sau negativ starea au fost \(causes.map { $0.name }.joined(separator: " + ").lowercased()). Nu este garantat ca acesti factori au dus la o emotie specifica, pur si simplu au avut un impact asupra starii. Scopul tău este sa îl faci sa-si inteleaga mai bine sentimentele, sa proceseze cum au contribuit cauzele mentionate mai sus + evenimentele de astăzi la starea lui actuala si să-i dai sfaturi / soluții. Ofera-i intrebari scurte, care il indruma spre directia cea buna si cuvinte de incurajare din cand in cand, la fel, scurte, dar calde. Daca utilizatorul intreaba ceva ce nu e deloc legat de dezvoltare personala, refuza sa-i raspunzi politicos. Ai voie sa te abati de la subiect daca iti cere sfaturi, conditia fiind sa revii imediat. Vorbeste pe un ton cald, semi-haios si intelegator, ca si cum esti prietenul lui si asigura-te ca nu se simte judecat. Conversatia sa fie fluida si daca nu schimba utilizatorul subiectul pentru mult timp, atunci schimba-l tu. \(UserInfo().userFirstName) a completat deja un chestionar, unde si-a specificat starea si ce a cauzat-o vag (vezi mai sus), deci poti sa incepi direct cu esenta. Initiaza conversatia printr-un mesaj scurt si la subiect, fara a face referire la aceste instructiuni. Incearca sa nu pui intrebari extrem de generale dupa primele cateva mesaje. Nu presupune nimic (de exemplu, daca apare mai sus ca utilizatorul se simte prost nu-l intreba de ce e complesit, intreaba-l de ce se simte prost si atat, sau, daca scrie mai sus de fitness, nu il intreba de antrenament, MAI PUTIN CAND SPECIFICA UTILIZATORUL INSUSI). "
//        ""
    }
    
    var body: some View {
        GeometryReader { geometry in
            let shouldBeGrid = geometry.size.width > MaxWidths().shouldTipsBeGrid
            
            ScrollViewReader { proxy in
                VStack(spacing: 16) {
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 12) {
                            
                            JournalSectionHeaderView(
                                header: "In sfarsit...",
                                title: "Haide sa aprofundam!",
                                isVisible: true
                            )
                            
                            VStack(spacing: 14) {
                                ForEach(chatMessages) { message in
                                    VStack(alignment: .leading, spacing: 24) {
                                        HStack {
                                            if message.sender == .user { Spacer(minLength: 80) }
                                            
                                            if trimExtraNewlines(from: message.content.components(separatedBy: "@TITLE@")[0]) != "" {
                                                Text(trimExtraNewlines(from: message.content.components(separatedBy: "@TITLE@")[0]))
                                                    .chatMessageStyle(accentColor: accentColor, isUser: message.sender == .user)
                                                
                                                if message.sender == .gpt { Spacer(minLength: 80) }
                                            }
                                        }
                                        
                                        if message.sender == .gpt && message.content.contains("@LIST@") {
                                            
                                            HStack {
                                                Spacer(minLength: 0)
                                                
                                                CardTipsView(
                                                    tips: extractTips(from: message.content),
                                                    title: extractTitle(from: message.content),
                                                    organizedSelectedTips: $organizedSelectedTips,
                                                    shouldBeGrid: shouldBeGrid,
                                                    showIndexByPosition: true
                                                )
                                                .padding(.top, 8)
                                                .padding(.bottom, 14)
                                                
                                                Spacer(minLength: 0)
                                            }
                                            
                                            if trimExtraNewlines(from: message.content.components(separatedBy: "@LIST@")[2]) != "" {
                                                HStack {
                                                    Text(trimExtraNewlines(from: message.content.components(separatedBy: "@LIST@")[2]))
                                                        .chatMessageStyle(accentColor: accentColor, isUser: message.sender == .user)
                                                    Spacer(minLength: 80)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            Color.red.opacity(0).frame(width: 1, height: 3)
                        }
                        .id("Bottom")
                    }
                    .mask(
                        VStack(spacing: 0) {
                            LinearGradient(colors: [.red.opacity(0), .red], startPoint: .top, endPoint: .bottom).frame(height: 6)
                            Color.red
                            LinearGradient(colors: [.red.opacity(0), .red], startPoint: .bottom, endPoint: .top).frame(height: 6)
                        }
                    )
                    .shadow(color: Color.black.opacity(0.02), radius: 6, x: 4, y: 8)
                    
//                    Button(action: {
//                        withAnimation(.smooth(duration: 0.2)) {
//                            showQuizScalePicker.toggle()
//                        }
//                    }) {
//                        Text("Schimba")
//                    }
                    
                    ZStack(alignment: .bottomTrailing) {
                        HStack(spacing: 12) {
                            if openAIService.isLoading || load || openAIService.isSummaryLoading {
                                ProgressView()
                            }
                            
                            TextField(openAIService.isLoading || load || openAIService.isSummaryLoading ? "Stevie se gandeste" : "Scrie un mesaj...", text: $message, axis: .vertical)
                                .tint(.secondary)
                                .disabled(openAIService.isLoading || load || openAIService.isSummaryLoading)
                            
                            Spacer(minLength: 0)
                        }
                        .padding(.leading, 16)
                        .padding(.trailing, 58)
                        .padding(.vertical, 12)
                        .lineLimit(1...12)
                        .frame(minHeight: 42)
                        .foregroundColor(.primary)
                        .background(Color(.systemBackground))
                        .cornerRadius(12)
                        .shadow(color: .black.opacity(0.03), radius: 4, x: 2, y: 4)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(
                                    accentColor.opacity(0.2),
                                    lineWidth: 0.3
                                )
                        )
                        .animation(.smooth(duration: 0.2), value: openAIService.isLoading || load)
                        
                        
                        Button(action: {
                            let messageSentToGPT = message
                            DispatchQueue.main.async {
                                withAnimation {
                                    chatMessages.append(ChatMessage(id: UUID().uuidString, content: message, dateCreated: Date(), sender: .user))
//                                        chatMessages.append(ChatMessage(id: UUID().uuidString, content: "raspunsul vine aiciiii", dateCreated: Date(), sender: .gpt))
                                    message = ""
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                                        withAnimation {
                                            proxy.scrollTo("Bottom", anchor: .bottom)
                                        }
                                    }
                                }
                            }
                            openAIService.sendMessage(message: messageSentToGPT)
                        }) {
                            Image(systemName: "paperplane.fill")
                                .foregroundColor(Color(.systemBackground))
                                .frame(width: 34, height: 34)
                                .background(Color.primary)
                                .cornerRadius(10)
                                .rotationEffect(.degrees(90))
                        }
                        .staggeredAppear(isVisible: showSendButton && !openAIService.isLoading, index: 0, offset: 3, duration: 0.24)
                        .rotationEffect(.degrees(-90))
                        .padding(6)
                    }
                    .frame(maxWidth: MaxWidths().maxStandardWidth)
                    .gesture(
                        DragGesture()
                            .onChanged { _ in
                                hideKeyboard()
                            }
                    )
                }
                .onAppear {
//                    openAIService.initialize(initialPrompt: prompt)
//                    openAIService.sendMessage(message: "SISTEM: Incepe o conversatie in limba romana cu utilizatorl.")
                    
                    // DOAR PT TESTARE
//                    withAnimation {
//                        proxy.scrollTo("Bottom", anchor: .bottom)
//                    }
                }
                .onReceive(openAIService.$responseMessage) { response in
                    if !response.isEmpty {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0) {
                            withAnimation {
                                chatMessages.append(ChatMessage(id: UUID().uuidString, content: response, dateCreated: Date(), sender: .gpt))
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            withAnimation {
                                proxy.scrollTo("Bottom", anchor: .bottom)
                            }
                        }
                    }
                }
                .onChange(of: message) {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        if message != "" {
                            showSendButton = true
                        } else {
                            showSendButton = false
                        }
                    }
                }
//                .onChange(of: openAIService.isLoading || load) {
//                    withAnimation {
//                        message = ""
//                    }
//                }
            }
        }
    }
}

#Preview {
    ZStack {
        Color(.systemGray6)
            .edgesIgnoringSafeArea(.all)
        
        ChatView(
//            chatMessages: [],
            chatMessages: ChatMessage.sampleMessages,
            accentColor: .accentColor,
            emotions: .constant([]),
            causes: .constant([]),
            organizedSelectedTips: .constant([:])
        )
        .environmentObject(OpenAIService())
        .environmentObject(UserInfo())
        .frame(maxWidth: MaxWidths().maxExpandedContentWidth)
        .padding(32)
    }
}
