//
//  VideoCardView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 22.07.2024.
//

import AVFoundation
import AVKit
import SwiftUI

struct VideoCardView: View {
    
    var showPlayerInAnotherView: Bool = true
    
    var title: String
    var description: String
    var urlString: String
    
    @State private var presentPlayerInAnotherView = false
    
    @State private var player: AVPlayer?
    @State private var extendPlayer = false
    @State private var showControls = true
    
    var accentColor: Color?
    
    let startingHeight: CGFloat = 480
    
    var body: some View {
        VStack(spacing: 28) {
            if extendPlayer && !showPlayerInAnotherView {
                VideoPlayer(player: player)
                    .disabled(!extendPlayer)
                    .aspectRatio(9/16, contentMode: .fit)
                    .cornerRadius(12)
            }
            
            VStack(spacing: 28) {
                if !extendPlayer {
//                    Image("Thumbnail2")
//                        .resizable()
//                        .scaledToFill()
//                        .frame(height: 160, alignment: .center)
//                        .clipped()
//                        .cornerRadius(12)
                    ZStack {
                        Color(.systemBackground)
                            .frame(height: 140, alignment: .center)
                            .cornerRadius(12)
                            .shadow(color: .black.opacity(0.1), radius: 12, x: 4, y: 2)
                        Image(systemName: "play.tv")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 52, height: 52)
                            .foregroundColor(accentColor ?? .accentColor)
                    }
                }
                
                LectureCardOverlayView(
                    title: title,
                    description: description,
                    buttonImage: extendPlayer ? "xmark" : "play.fill",
                    buttonText: extendPlayer ? "Inchide" : "Incepe",
                    action: {
                        withAnimation(.smooth(duration: 0.6)) {
                            if showPlayerInAnotherView {
                                presentPlayerInAnotherView = true
                            } else {
                                if extendPlayer {
                                    extendPlayer = false
                                    player?.pause()
                                    showControls = false
                                } else {
                                    extendPlayer = true
                                    player?.play()
                                    showControls = true
                                }
                            }
                        }
                    }
                )
            }
            .padding(32)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(color: .primary.opacity(0.1), radius: 16, x: 16, y: 4)
        }
        .navigationDestination(isPresented: $presentPlayerInAnotherView) {
            VideoPlayer(player: player)
                .edgesIgnoringSafeArea(.all)
                .navigationBarBackButtonHidden()
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        player?.play()
                    }
                }
                .overlay(alignment: .topLeading) {
                    Button(action: {
                        presentPlayerInAnotherView = false
                        player?.pause()
                    }) {
                        Image(systemName: "xmark")
                            .foregroundColor(.white)
                            .shadow(color: .primary.opacity(0.32), radius: 8, x: 4, y: 2)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 36)
                            .imageScale(.large)
                    }
                }
        }
            
        .onAppear {
            let urlString = urlString
            
            if let url = URL(string: urlString) {
                player = AVPlayer(url: url)
            } else {
                print("Invalid URL: \(urlString)")
            }
        }
        .onDisappear {
            player?.pause()
        }
    }
}

struct LectureCardOverlayView: View {
    
    var title: String
    var description: String
    
    var buttonImage: String
    var buttonText: String
    var action: (() -> Void)
    
    var body: some View {
            
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 14) {
                Text("Video")
                    .font(.subheadline.smallCaps())
                    .padding(.bottom, -12)
                Text(title)
                    .font(.title)
                    .fontWeight(.semibold)
                Text(description)
                    .font(.subheadline)
                    .padding(.bottom, 10)
                
                Button(action: {
                    action()
                }) {
                    HStack(spacing: 10) {
                        Spacer()
                        Image(systemName: buttonImage)
                        Text(buttonText)
                            .font(.headline)
                        Spacer()
                    }
                    .padding(6)
                }
                .buttonStyle(BorderedButtonStyle())
                .foregroundColor(.accentColor)
            }
            .fixedSize(horizontal: false, vertical: true)
            
            Spacer(minLength: 0)
        }
        .multilineTextAlignment(.leading)
    }
}

#Preview {
    NavigationStack {
        ScrollView {
            VideoCardView(
                title: "Ce este anxietate?",
                description: "Dr. Psihoterapeut Diana Todeanca discuta despre rolul acesteia in viata cotidiana.",
                urlString: "https://videos.pexels.com/video-files/6010502/6010502-uhd_1440_2560_25fps.mp4"
            )
            .padding(32)
        }
    }
}
