//
//  HipoHiperAlertView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 23.07.2024.
//

import SwiftUI

struct HipoHiperAlertView: View {
    var body: some View {
        HStack(spacing: 0) {
            
            Spacer(minLength: 0)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 20) {
                    ZStack {
                        Circle()
                            .foregroundColor(Color(.fericit))
                            .blur(radius: 6)
                        Circle()
                            .stroke(Color(.fericit), lineWidth: 2)
                            .brightness(0.1)
                            .padding(10)
                    }
                    .frame(width: 52, height: 52)

                    VStack(alignment: .leading) {
                        Text("Mesaj importat")
                            .font(.subheadline.smallCaps())
                        Text("Hiper-Activare")
                            .font(.title2)
                            .bold()
                    }
                }
                .padding(.bottom, 16)
                
                Text("Am observat că ești puțin hiper-activat de cateva zile.") 
                Text("Prin urmare, iti voi recomanda mai multe activitati care te vor calma si te va aduce, incetul cu incetul, inapoi la o stare optima. Ne auzim maine!")
                    .foregroundStyle(.secondary)
                
                HStack {
                    Spacer()
                    Text("- Stivie")
                        .multilineTextAlignment(.trailing)
                }
            }
            
            Spacer(minLength: 0)
        }
        .padding([.horizontal, .top], 32)
        .padding(.bottom, 28)
        .background(
            ZStack {
                Color(.systemBackground)
            }
        )
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.06), radius: 10, x: 6, y: 6)
    }
}

#Preview {
    HipoHiperAlertView()
        .padding(32)
}
