//
//  ImagePickerAndClassificationView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 23.07.2024.
//

import CoreML
import PhotosUI
import Vision
import SwiftUI
import UIKit
struct ImagePickerAndClassificationView: View {
    
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var selectedImages: [ClassifiedImage] = []
    
    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                PhotosPicker("Selecteaza imagini", selection: $selectedItems, matching: .images)
                
                ForEach(selectedImages) { classifiedImage in
                    classifiedImage.image
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(12)
                        .saturation(classifiedImage.string == "not flowers" ? 0 : 1.0)
                        .overlay(
                            VStack {
                                if classifiedImage.string == "not flowers" {
                                    Text("Frauda.")
                                        .bold()
                                        .foregroundStyle(.red)
                                        .padding(.horizontal, 12)
                                        .background(Color.black)
                                }
                            }
                        )
                        .frame(maxWidth: 400)
                }
            }
            .padding(32)
        }
        .onChange(of: selectedItems) {
            Task {
                selectedImages.removeAll()

                for item in selectedItems {
                    if let data = try? await item.loadTransferable(type: Data.self),
                       let uiImage = UIImage(data: data),
                       let fixedUIImage = fixImageOrientation(uiImage: uiImage) {
                        let image = Image(uiImage: fixedUIImage)
                        var classifiedImage = ClassifiedImage(image: image)
                        selectedImages.append(classifiedImage)
                        
                        classifyImage(image: fixedUIImage) { result in
                            if let index = selectedImages.firstIndex(where: { $0.id == classifiedImage.id }) {
                                DispatchQueue.main.async {
                                    selectedImages[index].string = result
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


//struct ImageClassifierView: View {
//    @State private var classificationLabel: String = "Classifying..."
//    private var imageName: String
//    
//    init(imageName: String) {
//        self.imageName = imageName
//    }
//    
//    var body: some View {
//        VStack {
//            Image(imageName)
//                .resizable()
//                .scaledToFit()
//                .onAppear(perform: classifyImage)
//            
//            Text(classificationLabel)
//                .padding()
//        }
//    }
//    
//    private func classifyImage() {
//        guard let model = try? FlowerImageClassifierModel(configuration: MLModelConfiguration()).model else {
//            classificationLabel = "Failed to load model"
//            return
//        }
//        
//        guard let visionModel = try? VNCoreMLModel(for: model) else {
//            classificationLabel = "Failed to create Vision model"
//            return
//        }
//        
//        let request = VNCoreMLRequest(model: visionModel) { request, error in
//            if let results = request.results as? [VNClassificationObservation],
//               let topResult = results.first {
//                DispatchQueue.main.async {
//                    
//                    // REZULTATUL AICI
//                    classificationLabel = "\(topResult.identifier)"
//                }
//            } else if let error = error {
//                DispatchQueue.main.async {
//                    classificationLabel = "Error: \(error.localizedDescription)"
//                }
//            } else {
//                DispatchQueue.main.async {
//                    classificationLabel = "Unknown classification"
//                }
//            }
//        }
//        
//        guard let image = UIImage(named: imageName),
//              let ciImage = CIImage(image: image) else {
//            classificationLabel = "Failed to load image"
//            return
//        }
//        
//        let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
//        DispatchQueue.global(qos: .userInteractive).async {
//            do {
//                try handler.perform([request])
//            } catch {
//                DispatchQueue.main.async {
//                    classificationLabel = "Failed to perform classification: \(error.localizedDescription)"
//                }
//            }
//        }
//    }
//}

#Preview {
    ImagePickerAndClassificationView()
//    ImageClassifierView(imageName: "flower")
}
