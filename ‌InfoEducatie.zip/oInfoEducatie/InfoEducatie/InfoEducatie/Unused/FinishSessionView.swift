//
//  FinishSessionView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 22.06.2024.
//

import SwiftUI

struct FinishSessionView: View {
    var body: some View {
        Text("Finalizeaza sesiunea")
    }
}

#Preview {
    FinishSessionView()
        .padding()
}
