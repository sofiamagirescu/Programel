//
//  VideoPlayerControllerView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 23.07.2024.
//

import SwiftUI
import AVKit
import AVFoundation

class Coordinator: NSObject, AVPlayerViewControllerDelegate {
    var parent: VideoPlayerControllerView

    init(_ parent: VideoPlayerControllerView) {
        self.parent = parent
    }

    func playerViewController(_ playerViewController: AVPlayerViewController, willBeginFullScreenPresentationWithAnimationCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        parent.isFullScreen = true
    }

    func playerViewController(_ playerViewController: AVPlayerViewController, willEndFullScreenPresentationWithAnimationCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        parent.isFullScreen = false
    }
}

struct VideoPlayerControllerView: UIViewControllerRepresentable {
    @Binding var player: AVPlayer?
    @Binding var showControls: Bool
    @Binding var isFullScreen: Bool

    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let playerViewController = AVPlayerViewController()
        playerViewController.delegate = context.coordinator
        return playerViewController
    }

    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        uiViewController.player = player
        uiViewController.showsPlaybackControls = showControls
        uiViewController.entersFullScreenWhenPlaybackBegins = isFullScreen
    }
}
