//
//  TextFieldModifier.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 25.07.2024.
//

import SwiftUI

struct TextFieldModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundColor(.primary)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.08), radius: 12, x: 2, y: 4)
    }
}

extension View {
    func textFieldStyle() -> some View {
        self.modifier(TextFieldModifier())
    }
}
