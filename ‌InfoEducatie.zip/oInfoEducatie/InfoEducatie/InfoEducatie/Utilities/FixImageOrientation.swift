//
//  FixImageOrientation.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 23.07.2024.
//

import UIKit

func fixImageOrientation(uiImage: UIImage) -> UIImage? {
    guard uiImage.imageOrientation != .up else { return uiImage }

    UIGraphicsBeginImageContextWithOptions(uiImage.size, false, uiImage.scale)
    uiImage.draw(in: CGRect(origin: .zero, size: uiImage.size))

    let normalizedImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    return normalizedImage
}
