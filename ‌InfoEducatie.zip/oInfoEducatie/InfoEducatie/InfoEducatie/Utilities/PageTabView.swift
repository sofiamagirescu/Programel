//
//  PageTabView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 25.07.2024.
//

import SwiftUI
import UIKit

struct CustomTabView<Content: View>: UIViewControllerRepresentable {
    @Binding var selection: Int
    @Binding var isTabChangeDisabled: Bool
    var content: () -> Content

    init(selection: Binding<Int>, isTabChangeDisabled: Binding<Bool>, @ViewBuilder content: @escaping () -> Content) {
        self._selection = selection
        self._isTabChangeDisabled = isTabChangeDisabled
        self.content = content
    }

    func makeUIViewController(context: Context) -> UIViewController {
        let hostingController = UIHostingController(rootView: content())
        let viewController = UIViewController()
        viewController.addChild(hostingController)
        viewController.view.addSubview(hostingController.view)
        hostingController.view.frame = viewController.view.bounds
        hostingController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        hostingController.didMove(toParent: viewController)
        return viewController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        if let hostingController = uiViewController.children.first as? UIHostingController<Content> {
            hostingController.rootView = content()

            // Manage gesture recognizers
            uiViewController.view.gestureRecognizers?.forEach { recognizer in
                if let panGesture = recognizer as? UIPanGestureRecognizer {
                    panGesture.isEnabled = !isTabChangeDisabled
                }
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject {
        var parent: CustomTabView

        init(_ parent: CustomTabView) {
            self.parent = parent
        }
    }
}
