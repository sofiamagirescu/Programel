//
//  BlurryBackgroundView.swift
//  InfoEducatie
//
//  Created by Calin Gavriliu on 16.07.2024.
//

import SwiftUI

struct BlurryBackgroundView: View {
    @Binding var colors: [Color]
    @State private var positions: [CGSize] = []
    @State private var targetPositions: [CGSize] = []
    
    var blurAmmount: CGFloat = 120
    var shouldAnimate: Bool = true
    
    private let devideSizeBy = 1.0
    private let colorsCount = 3
    private let animationDuration = 10

    var body: some View {
        ZStack {
            Color.average(colors: colors)
            
            GeometryReader { geometry in
                ZStack {
                    ForEach(0..<positions.count, id: \.self) { index in
                        if !colors.isEmpty {
                            Circle()
                                .fill(colors[index % colors.count])
                                .frame(width: geometry.size.width / devideSizeBy, height: geometry.size.height / devideSizeBy)
                                .position(x: positions[index].width, y: positions[index].height)
                        }
                    }
                }
                .onAppear {
                    if !colors.isEmpty {
                        initializePositions(for: geometry.size)
                        if shouldAnimate {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                randomizeTargetPositions(for: geometry.size)
                                animatePositions()
                            }
                        }
                    }
                }
                .onChange(of: colors) {
                    if !colors.isEmpty {
                        updatePositions(for: geometry.size)
                        randomizeTargetPositions(for: geometry.size)
                        animatePositions()
                    } else {
                        positions = []
                        targetPositions = []
                    }
                }
            }
        }
        .saturation(4.0)
        .blur(radius: blurAmmount)
//        .opacity(
//            colors.count > 3 ?
//            0.18
//            : 1 / Double((colors.count + 1))
//        )
        .edgesIgnoringSafeArea(.all)
    }

    private func initializePositions(for size: CGSize) {
        positions = []
        let centerX = size.width / 2
        let centerY = size.height / 2
        let centerOffset: CGFloat = 50

        // Ensure at least colorsCount - 1 circles of each color are near the center
        for _ in 0 ..< colors.count {
            for _ in 0 ..< (colorsCount - 1) {
                let x = centerX + CGFloat.random(in: -centerOffset...centerOffset)
                let y = centerY + CGFloat.random(in: -centerOffset...centerOffset)
                positions.append(CGSize(width: x, height: y))
            }
        }

        // Randomly place the remaining circles
        let remainingCircles = colors.count * colorsCount - positions.count
        for _ in 0..<remainingCircles {
            let x = CGFloat.random(in: 0...size.width)
            let y = CGFloat.random(in: 0...size.height)
            positions.append(CGSize(width: x, height: y))
        }

        targetPositions = Array(repeating: CGSize.zero, count: colors.count * colorsCount)
    }

    private func updatePositions(for size: CGSize) {
        let newCount = colors.count * colorsCount
        if positions.count != newCount {
            if positions.count > newCount {
                positions.removeLast(positions.count - newCount)
                targetPositions.removeLast(targetPositions.count - newCount)
            } else {
                for _ in positions.count..<newCount {
                    let x = CGFloat.random(in: 0...size.width)
                    let y = CGFloat.random(in: 0...size.height)
                    
                    positions.append(CGSize(width: x, height: y))
                }
                targetPositions.append(contentsOf: Array(repeating: CGSize.zero, count: newCount - targetPositions.count))
            }
        }
    }

    private func randomizeTargetPositions(for size: CGSize) {
        targetPositions = (0..<positions.count).map { _ in
            CGSize(width: CGFloat.random(in: 0...size.width), height: CGFloat.random(in: 0...size.height))
        }
    }

    private func animatePositions() {
        if !positions.isEmpty {
            withAnimation(Animation.linear(duration: TimeInterval(animationDuration)).repeatForever(autoreverses: true)) {
                for index in positions.indices {
                    positions[index] = targetPositions[index]
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + TimeInterval(animationDuration)) {
                randomizeTargetPositions(for: UIScreen.main.bounds.size)
                animatePositions()
            }
        }
    }
}

#Preview {
//    BlurryBackgroundView(colors: [.blue, .yellow, .purple, .orange, .pink])
    BlurryBackgroundView(colors: .constant([.blue, .indigo, .green, .red]))
        .opacity(0.2)
    
//    BlurryBackgroundView(colors: [])
}
